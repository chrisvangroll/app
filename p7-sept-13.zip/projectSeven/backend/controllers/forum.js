// const { restart } = require('nodemon');
// const mysql = require('mysql');

// const db = mysql.createConnection({
//       user: 'root',
//       host: 'localhost',
//       password: process.env.DB_PASSWORD,
//       database: 'groupomania'
//     })



// exports.getAllPosts = (req, res, next)=>{
//     let sql = "SELECT * FROM users";
//     db.query(sql, (err, results)=> {
//     res.send(results)
//     })
// }

