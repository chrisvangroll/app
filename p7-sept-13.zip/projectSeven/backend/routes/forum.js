const express = require('express');
const router = express.Router();
const forumCtrl = require('../controllers/forum');
const mysql = require('mysql');

const db = mysql.createConnection({
    user: 'root',
    host: 'localhost',
    password: process.env.DB_PASSWORD,
    database: 'groupomania'
  })

//   router.post('/', forumCtrl.createPost);

//   router.get('/', forumCtrl.getAllposts);

//   router.post('/:id/like', forumCtrl.createPost);

//   router.get('/:id', forumCtrl.getPost);

//   router.post('/:id/like', forumCtrl.createPost);

//   router.put('/:id', forumCtrl.updatePost);

//   router.delete('/:id', forumCtrl.deletePost);



module.exports = router;